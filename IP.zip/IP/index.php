<?php include("libs/config.php");?>
<?php
session_start();// Starting Session
$error=''; //variable to store error message
if(isset($_POST["login"]))
	{
		if (empty($_POST['username']) || empty($_POST['password'])) {
		echo "<script type='text/javascript'>
		$(document).ready(function(){
		$('#error').modal('show');
		});
		</script>";
	} else
	{
		$username = $_POST["username"];
		$password = $_POST["password"];
		
		
		$query = "SELECT * FROM addclient WHERE username='".$username."' AND password='".$password."'";
		
		$rows = mysql_num_rows(mysql_query($query));
		
		$rowval = mysql_fetch_array(mysql_query($query));
		
		if ($rows == 1) 
		{
			
				$_SESSION['addclient'] = $rowval["client_id"];//Initializing Session
				
				if($rowval["usertype"] == "admin")
				{
					echo '<script type="text/javascript">
						window.location="admin/index.php";
					</script>';    
				}
				if($rowval["usertype"] == "user")
				{
					echo '<script type="text/javascript">
						window.location="student/index.php";
					</script>';    
				}
				if($rowval["usertype"] == "staff")
				{
					echo '<script type="text/javascript">
						window.location="staff/index.php";
					</script>';    
				}
		} 
		else 
		{
			echo "<script type='text/javascript'>
		alert('Incorrect Username or Password');
		</script>";
			
		}
	}
}		
	

	
?>
<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Home | MGM CET</title>
<link rel="shortcut icon" href="../images/favicon.png" type="image/x-icon" /> 
<link href="assets/bootstrap/css/bootstrap.css" rel="stylesheet">

<link href="assets/css/style.css" rel="stylesheet">

<link href="assets/css/owl.carousel.css" rel="stylesheet">
<link href="assets/css/owl.theme.css" rel="stylesheet">
<script src='https://www.google.com/recaptcha/api.js'></script>



<script>
        paceOptions = {
            elements: true
        };
    </script>
<script src="assets/js/pace.min.js"></script>

</head>
<body>
<div class="col-md-12" style="background-color:black"><br><img src="img/logo1.png" height="80px" width="100%"><br><br></div><br><br><br><br>
<div class="container-fluid">

<div class="row" style="margin-top:50px">
<div class="col-md-8 col-lg-8 col-sm-12 col-xs-12">

<div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner">
      <div class="item active">
        <img src="img/slide1.png" style="width:100%;">
      </div>

      <div class="item">
        <img src="img/slide2.png" style="width:100%;">
      </div>
    
      <div class="item">
        <img src="img/slide3.jpg" style="width:100%;">
      </div>
    </div>

    <!-- Left and right controls -->
    <a class="left carousel-control" href="#myCarousel" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>

</div> 
<style>
#login{
	cursor:not-allowed;
}
recaptcha-container{
	text-align:center;
	.g-recaptcha > div{
		width:auto !important;
	}
}
}
</style>
<div class="col-md-4 col-lg-4 col-sm-12 col-xs-12">

<div class="panel panel-default" style="background-color: rgba(255, 255, 255, .8);">
<div class="panel-intro text-center">
<h2 class="logo-title">
<img src="img/logo.png" height="100px" width="100px"/> 
</h2>
<p><b>MGM's College of Engineering and Technology(MGMCET)</b></p>
</div>
<div class="panel-body" style="margin-top:-50px">
<form method="post" action="">
<div class="form-group">
<label for="sender-email" class="control-label"></label>
 <div class="input-icon" style=""><i class="icon-user fa"></i>
	<input type="text" autocomplete="off" name="username" id="username" class="form-control" placeholder="Username" style="height:51px;padding: 6px 40px;font-size:15px" required/>
	
</div>
</div>
<div class="form-group">
<label for="user-pass" class="control-label"></label>
<div class="input-icon"><i class="icon-home fa"></i>
<input type="password" autocomplete="off" name="password" id="password" class="form-control" Placeholder="Password" style="height:51px;padding: 6px 40px;font-size:15px" required />
</div>
</div>
<div class="form-group recaptcha-container">
   <div class="g-recaptcha" data-sitekey="6Lfo1XAUAAAAAHbZzxrUKuS-hDS6xVQnQiyA4_Af" data-callback="recaptcha_callback"></div>
</div>
<br>
<div class="form-group">
<button type="Submit" id="login" class="btn btn-primary btn-block" name="login" disabled>Login Now</button>
</div>
</form>
</div>
</div>

</div>

</div>


</div>
<br>
<div class="col-md-12" style="background-color:#550003; color:white"><br><center>©2018 MGM's College of Engineering and Technology(MGMCET).  All Rights Reserved.</center><br></div>




<script src="ajax.googleapis.com/ajax/libs/jquery/1.10.1/jquery.min.js"></script>
<script src="assets/bootstrap/js/bootstrap.min.js"></script>

<script src="assets/js/owl.carousel.min.js"></script>

<script src="assets/js/form-validation.js"></script>

<script src="assets/js/jquery.matchHeight-min.js"></script>

<script src="assets/js/hideMaxListItem.js"></script>

<script src="assets/plugins/jquery.fs.scroller/jquery.fs.scroller.js"></script>
<script src="assets/plugins/jquery.fs.selecter/jquery.fs.selecter.js"></script>

<script src="assets/js/script.js"></script>
<script>
function recaptcha_callback(){
	var recaptchabtn = document.querySelector('#login');
	recaptchabtn.removeAttribute('disabled');
	recaptchabtn.style.cursor = 'pointer';
}
</script>

</body>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
</html>
