 <?php include("header.php")?>

 
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
   <section class="content-header">
      <h1>
        All Records
        <small>advanced tables</small>
      </h1>
   </section>

 <?php
   $query = mysql_query("select count(*) as total from addclient where usertype='user' ");
	$row_user = mysql_fetch_assoc($query);
	$total_students = $row_user["total"];
	
	$query2 = mysql_query("select count(*) as total2 from addclient where usertype='staff' ");
	$row_user2 = mysql_fetch_assoc($query2);
	$total_staffs = $row_user2["total2"];
?>
   
    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      <div class="row">
	    <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-aqua">
            <div class="inner">
              <h3><?php echo $total_staffs?></h3>

              <p>Total Staffs</p>
            </div>
            <div class="icon">
              <i class="ion ion-bag"></i>
            </div>
            <a href="view_staffs.php" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-red">
            <div class="inner">
              <h3><?php echo $total_students?></h3>

              <p>Total Students</p>
            </div>
            <div class="icon">
              <i class="ion ion-bag"></i>
            </div>
            <a href="view_students.php" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
		
        <!-- ./col -->
       
      </div>
      <!-- /.row -->
      <!-- Main row -->
      

        </section>
        <!-- right col -->
      </div>
      <!-- /.row (main row) -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
 
 <?php include("footer.php")?>