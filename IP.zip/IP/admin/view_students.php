<?php include("header.php")?>
<?php
    if (isset($_REQUEST["del"]) && $_REQUEST["del"] != "" ) 
		{
			$del = $_REQUEST["del"];
			$query = "DELETE FROM addclient WHERE `client_id` = ".$_REQUEST["del"];			
			
			$stmt = mysql_query($query);
			if ($stmt) 
			{
				
				
						echo("<script type='text/javascript'>
						
							alert('Deleted');
					
						</script>");
					
			}
			else 
			{
				
				echo("<script type='text/javascript'>
					
					alert('Not Deleted');
					
						</script>");
				
			}	
		}

?>


<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Student Records
        <small>advanced tables</small>
      </h1>
      
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
				  <th><input type="checkbox"/></th>
				  <th>Sr no.</th>
                  <th>Student Full Name</th>
                  <th>Email Address</th>
                  <th>Contact</th>
                  <th>Username</th>
				  <th>Password</th>
                </tr>
                </thead>
                <tbody>
<?php
 $count = 1;
   $query = mysql_query("select * from addclient WHERE usertype = 'user' order by client_id desc");
   
   while($row = mysql_fetch_array($query))
   {
	   
?>
                <tr>
				  <td><input type="radio" name="chkNumber" class="chkNumber" value="<?php echo $row["client_id"]?>"></td>
				  <td><?php echo $count?></td>
                  <td><?php echo $row["f_name"]?> <?php echo $row["m_name"]?> <?php echo $row["l_name"]?></td>
                  <td><?php echo $row["email"]?></td>
                  <td><?php echo $row["contact"]?></td>
				  <td><b style="color:green"><?php echo $row["username"]?></b></td>
				  <td><b style="color:green"><?php echo $row["password"]?></b></td>
                </tr>
<?php
$count++;
   }
?>
				
              </tbody>
              </table><br>
			  <button type="submit" class="btn btn-info" name="view" id="view">View</button>
              <button type="submit" class="btn btn-danger" id="delete" name="delete">Delete</button><br>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
	
    <!-- /.content -->
  </div>
<?php include("footer.php")?>
<script>
 $(document).on("click","#view",function(e){
		
			if ($('.chkNumber:checked').length) {
				  var chkId = '';
				  $('.chkNumber:checked').each(function () {
					chkId += $(this).val() + ",";
				  });
				  chkId = chkId.slice(0, -1);
				 //alert(chkId);
				 location.href = "view_students_details.php?view=" + chkId ;
				}
				else {
				  alert('Nothing Selected');
				}
			
		});
</script>
<script>
 $(document).on("click","#delete",function(e){
		
			if ($('.chkNumber:checked').length) {
				  var chkId = '';
				  $('.chkNumber:checked').each(function () {
					chkId += $(this).val() + ",";
				  });
				  chkId = chkId.slice(0, -1);
				 //alert(chkId);
				 location.href = "view_students.php?del=" + chkId ;
				}
				else {
				  alert('Nothing Selected');
				}
			
		});
</script>
