<?php include("header.php")?>

<?php
     if(isset($_POST["student_submit"]))
	 {
		 $f_name = $_POST["f_name"];
		 $m_name = $_POST["m_name"];
		 $l_name = $_POST["l_name"];
		 $dob = $_POST["dob"];
		 $age = $_POST["age"];
		 $gender = $_POST["gender"];
		 $cast = $_POST["cast"];
		 $address = $_POST["address"];
		 $email = $_POST["email"];
		 $contact = $_POST["contact"];
		 $nationality = $_POST["nationality"];
		 $location = $_POST["location"];
		 $city = $_POST["city"];
		 $father_name = $_POST["father_name"];
		 $f_mname = $_POST["f_mname"];
		 $f_lname = $_POST["f_lname"];
		 $mother_name = $_POST["mother_name"];
		 $m_mname = $_POST["m_mname"];
		 $m_lname = $_POST["m_lname"];
		 $g_name = $_POST["g_name"];
		 $g_mname = $_POST["g_mname"];
		 $g_mname = $_POST["g_mname"];
		 $g_lname = $_POST["g_lname"];
		 $course = $_POST["course"];
		 $course_year = $_POST["course_year"];
		 $shift = $_POST["shift"];
		 $status = '0';
		 $created_date = date("d-M-Y");
		 $username = $_POST["username"];
	     $password = $_POST["password"];
		 $characters = 'abc123';
		$string = '';
		$string1 = '';
		$string2 = '';
		$string6 = '';
			$profile_image = $_FILES["fruit_img"]["name"];
				
			if($profile_image <> "")
			{

				for($j = 0; $j < count($profile_image); $j++)
				{
					
				for($i = 0; $i < 0; $i++) {
					$string .= $characters[rand(0, strlen($characters) - 1)];
				}	
				$profile_imagePath = "fruit/" . $string . $profile_image[$j];

				move_uploaded_file($_FILES["fruit_img"]["tmp_name"][$j], $profile_imagePath);
				}	
			}
		 
		 $query="INSERT INTO `addclient`(`f_name`, `m_name`, `l_name`, `dob`, `age`, `gender`, `cast`, `address`, `email`, `contact`, `nationality`, `location`, `city`, `father_name`, `f_mname`, `f_lname`, `mother_name`, `m_mname`, `m_lname`, `g_name`, `g_mname`, `g_lname`, `course`, `course_year`, `shift`, `image`, `status`, `created_date`, `login_id`, `username`, `password`, `usertype`) VALUES ('$f_name','$m_name','$l_name','$dob','$age','$gender','$cast','$address','$email','$contact','$nationality','$location','$city','$father_name','$f_mname','$f_lname','$mother_name','$m_mname','$m_lname','$g_name','$g_mname','$g_lname','$course','$course_year','$shift','$profile_imagePath','$status','$created_date','$user_check','$username','$password','user')";
	 
         $que = mysql_query($query);
		 
         if($que)
		 {
            		echo '<script>alert("Student is Registered")</script>';
		 }else
         {
			        echo '<script>alert("Something Went wrong")</script>';
		 }			 
	 }

?>
  
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Add Student
      </h1>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
            
            <!-- /.box-header -->
            <!-- form start -->
            <form method="post" action="" enctype="multipart/form-data">
              <div class="box-body">
			    <input type="hidden" name="username" id="username" value="<?php echo ''.mt_rand(1000000000,9999999999)?>"/>
			    <input type="hidden" name="password" id="password" value="<?php echo ''.mt_rand(100000,999999)?>"/>
			    <div class="form-group col-md-3">
							<img src="images/1313308622.jpg "id="blah" src="#" name=""  class="img-circle" style="width:100px; height:100px;"/>
							<input type='file' id="imgInp" style="padding-top:5px" name="fruit_img[]"/>
                </div>
                <div class="form-group col-md-3" style="margin-top:20px">
                  <label>First Name</label>
                  <input type="text" class="form-control" name="f_name" id="f_name" placeholder="Enter First Name">
                </div>
                <div class="form-group  col-md-3" style="margin-top:20px">
                  <label>Middle Name</label>
                  <input type="text" class="form-control" name="m_name" id="m_name" placeholder="Enter Middle Name">
                </div>
                <div class="form-group  col-md-3" style="margin-top:20px">
                  <label>Last name</label>
                  <input type="text" class="form-control" name="l_name" id="l_name" placeholder="Enter Last Name">
                </div>
              </div>
			  
			  <div class="row">
			     <div class="col-md-12">
			        <div class="form-group col-md-2">
                          <label>D.O.B</label>
                          <input type="text" class="form-control" name="dob" id="dob" placeholder="DD-MM-YYY">
                    </div>
					<div class="form-group col-md-2">
                          <label>Age</label>
                          <input type="text" class="form-control" name="age" id="age" placeholder="Age">
                    </div>
                    <div class="form-group col-md-4">
                          <label>Gender</label><br>
                          <select class="form-control select2" name="gender" id="gender" style="width: 100%;">
								<option value="Male">Male</option>
								<option value="Female">Female</option>
						  </select>
                    </div>
                    <div class="form-group  col-md-4">
                          <label>Cast</label>
                          <select class="form-control select2" name="cast" id="cast" style="width: 100%;">
								<option value="Hindu">Hindu</option>
								<option value="Marathi">Marathi</option>
								<option value="Gujarati">Gujarati</option>
						  </select>
                    </div>
			     </div>
			  </div>
			  
			  <div class="row">
			     <div class="col-md-12">
			        <div class="form-group col-md-4">
                          <label>Address</label>
                          <input type="text" class="form-control" name="address" id="address" placeholder="Enter Address"/>
                    </div>
                    <div class="form-group col-md-4">
                          <label>Email Address</label><br>
                          <input type="email" class="form-control" name="email" id="email" placeholder="Enter Email Address"/>
                    </div>
                    <div class="form-group  col-md-4">
                          <label>Contact</label>
                          <input type="number" class="form-control" name="contact" id="contact" placeholder="Enter Contact"/>
                    </div>
			     </div>
			  </div>
			  
			  <div class="row">
			     <div class="col-md-12">
			        <div class="form-group col-md-4">
                          <label>Nationality</label>
                          <select class="form-control select2" name="nationality" id="nationality" style="width:100%;">
								<option value="Indian">Indian</option>
								<option value="Foreign_National">Foreign National</option>
						  </select>
                    </div>
                    <div class="form-group col-md-4">
                          <label>Location</label><br>
                          <select class="form-control select2" name="location" id="location" style="width: 100%;">
								<option value="kalyan">kalyan</option>
								<option value="Thane">Thane</option>
						  </select>
                    </div>
                    <div class="form-group  col-md-4">
                          <label>City</label>
                          <select class="form-control select2" name="city" id="city" style="width: 100%;">
								<option value="Mumbai">Mumbai</option>
								<option value="Navi_Mumbai">Navi Mumbai</option>
						  </select>
                    </div>
			     </div>
			  </div>
              <!-- /.box-body -->

			  
			 
			  
			  <h2 style="margin-left:12px"></b>Family Detail</b></h2><br>
			  <div class="row">
			       <div class="col-md-12">
						<div class="form-group col-md-4">
						  <input type="text" class="form-control" name="father_name" id="father_name" placeholder="Father First Name">
						</div>
						<div class="form-group  col-md-4">
						  <input type="text" class="form-control" name="f_mname" id="f_mname" placeholder="Middle Name">
						</div>
						<div class="form-group  col-md-4">
						  <input type="text" class="form-control" name="f_lname" id="f_lname" placeholder="Last Name">
						</div>
					</div>
			  </div>
			  <div class="row">
			        <div class="col-md-12">
						<div class="form-group col-md-4">
						  <input type="text" class="form-control" name="mother_name" id="mother_name" placeholder="Mother First Name">
						</div>
						<div class="form-group  col-md-4">
						  <input type="text" class="form-control" name="m_mname" id="m_mname" placeholder="Middle Name">
						</div>
						<div class="form-group  col-md-4">
						  <input type="text" class="form-control" name="m_lname" id="m_lname" placeholder="Last Name">
						</div>
					</div>
			  </div>
			  <div class="row">
			        <div class="col-md-12">
						<div class="form-group col-md-4">
						  <input type="text" class="form-control" name="g_name" id="g_name" placeholder="Guardian First Name">
						</div>
						<div class="form-group  col-md-4">
						  <input type="text" class="form-control" name="g_mname" id="g_mname" placeholder="Middle Name">
						</div>
						<div class="form-group  col-md-4">
						  <input type="text" class="form-control" name="g_lname" id="g_lname" placeholder="Last Name">
						</div>
					 </div>
			  </div>
			  
			  <h2 style="margin-left:12px"></b>Apply For</b></h2><br>
			     <div class="row">
				  <div class="col-md-12">
			        <div class="form-group col-md-4">
                          <label>Course</label>
                          <select class="form-control select2" name="course" id="course" style="width: 100%;">
								<option value="IT">IT</option>
								<option value="Computer">Computer</option>
								<option value="Mechanical">Mechanical</option>
								<option value="Civil">Civil</option>
								<option value="Automobile">Automobile</option>
								<option value="Elect & Telecom">Elect & Telecom</option>
								<option value="Electrical">Electrical</option>
						  </select>
                    </div>
 					<div class="form-group col-md-4">
                          <label>Year</label>
                          <select class="form-control select2" name="course_year" id="course_year" style="width: 100%;">
								<option value="first_Semester">1st Semester</option>
								<option value="second_Semester">2nd Semester</option>
								<option value="third_semester">3rd Semester</option>
								<option value="fourth_semester">4th Semester</option>
								<option value="fifth_semester">5th Semester</option>
								<option value="sixth_semester">6th Semester</option>
						  </select>
                    </div>
					<div class="form-group col-md-4">
                          <label>Shift</label>
                          <select class="form-control select2" name="shift" id="shift" style="width: 100%;">
								<option value="none">none</option>
								<option value="1st Shift">1st Shift</option>
								<option value="2nd Shift">2nd Shift</option>
						  </select>
                    </div>
				  </div>
				 </div>
					
				
              <div class="box-footer">
			    <center>
			    <button type="submit" class="btn btn-primary" name="student_submit" id="student_submit">Submit</button>
                <button type="submit" class="btn btn-warning">Reset</button>
				</center>
              </div>
            </form>
          </div>
          <!-- /.box -->
        </div>
		
		
        
        <!--/.col (right) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  
  <?php include("footer.php")?>