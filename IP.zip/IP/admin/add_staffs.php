<?php include("header.php")?>

<?php
     if(isset($_POST["student_submit"]))
	 {
		 $f_name = $_POST["f_name"];
		 $m_name = $_POST["m_name"];
		 $l_name = $_POST["l_name"];
		 $dob = $_POST["dob"];
		 $age = $_POST["age"];
		 $gender = $_POST["gender"];
		 $cast = $_POST["cast"];
		 $address = $_POST["address"];
		 $email = $_POST["email"];
		 $contact = $_POST["contact"];
		 $nationality = $_POST["nationality"];
		 $location = $_POST["location"];
		 $city = $_POST["city"];
		 
		 $course = $_POST["course"];
		 $course_year = $_POST["course_year"];
		 $shift = $_POST["shift"];
		 $subject = $_POST["subject"];
		 $status = '0';
		 $created_date = date("d-M-Y");
		 $username = $_POST["username"];
	     $password = $_POST["password"];
		 $characters = 'abc123';
		$string = '';
		$string1 = '';
		$string2 = '';
		$string6 = '';
			$profile_image = $_FILES["fruit_img"]["name"];
				
			if($profile_image <> "")
			{

				for($j = 0; $j < count($profile_image); $j++)
				{
					
				for($i = 0; $i < 0; $i++) {
					$string .= $characters[rand(0, strlen($characters) - 1)];
				}	
				$profile_imagePath = "fruit/" . $string . $profile_image[$j];

				move_uploaded_file($_FILES["fruit_img"]["tmp_name"][$j], $profile_imagePath);
				}	
			}
		 
		 $query="INSERT INTO `addclient`(`f_name`, `m_name`, `l_name`, `dob`, `age`, `gender`, `cast`, `address`, `email`, `contact`, `nationality`, `location`, `city`, `course`, `course_year`, `shift`, `subject`, `image`, `status`, `created_date`, `login_id`, `username`, `password`, `usertype`) VALUES ('$f_name','$m_name','$l_name','$dob','$age','$gender','$cast','$address','$email','$contact','$nationality','$location','$city','$course','$course_year','$shift','$subject','$profile_imagePath','$status','$created_date','$user_check','$username','$password','staff')";
	 
         $que = mysql_query($query);
		 
         if($que)
		 {
            		echo '<script>alert("Staff is Assign")</script>';
		 }else
         {
			        echo '<script>alert("Something Went wrong")</script>';
		 }			 
	 }

?>
  
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Add Staff
      </h1>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
            
            <!-- /.box-header -->
            <!-- form start -->
            <form method="post" action="" enctype="multipart/form-data">
              <div class="box-body">
			    <input type="hidden" name="username" id="username" value="<?php echo ''.mt_rand(1000000000,9999999999)?>"/>
			    <input type="hidden" name="password" id="password" value="<?php echo ''.mt_rand(100000,999999)?>"/>
			    <div class="form-group col-md-3">
							<img src="images/1313308622.jpg "id="blah" src="#" name=""  class="img-circle" style="width:100px; height:100px;"/>
							<input type='file' id="imgInp" style="padding-top:5px" name="fruit_img[]"/>
                </div>
                <div class="form-group col-md-3" style="margin-top:20px">
                  <label>First Name</label>
                  <input type="text" class="form-control" name="f_name" id="f_name" placeholder="Enter First Name">
                </div>
                <div class="form-group  col-md-3" style="margin-top:20px">
                  <label>Middle Name</label>
                  <input type="text" class="form-control" name="m_name" id="m_name" placeholder="Enter Middle Name">
                </div>
                <div class="form-group  col-md-3" style="margin-top:20px">
                  <label>Last name</label>
                  <input type="text" class="form-control" name="l_name" id="l_name" placeholder="Enter Last Name">
                </div>
              </div>
			  
			  <div class="row">
			     <div class="col-md-12">
			        <div class="form-group col-md-2">
                          <label>D.O.B</label>
                          <input type="text" class="form-control" name="dob" id="dob" placeholder="DD-MM-YYY">
                    </div>
					<div class="form-group col-md-2">
                          <label>Age</label>
                          <input type="text" class="form-control" name="age" id="age" placeholder="Age">
                    </div>
                    <div class="form-group col-md-4">
                          <label>Gender</label><br>
                          <select class="form-control select2" name="gender" id="gender" style="width: 100%;">
								<option value="Male">Male</option>
								<option value="Female">Female</option>
						  </select>
                    </div>
                    <div class="form-group  col-md-4">
                          <label>Cast</label>
                          <select class="form-control select2" name="cast" id="cast" style="width: 100%;">
								<option value="Hindu">Hindu</option>
								<option value="Marathi">Marathi</option>
								<option value="Gujarati">Gujarati</option>
						  </select>
                    </div>
			     </div>
			  </div>
			  
			  <div class="row">
			     <div class="col-md-12">
			        <div class="form-group col-md-4">
                          <label>Address</label>
                          <input type="text" class="form-control" name="address" id="address" placeholder="Enter Address"/>
                    </div>
                    <div class="form-group col-md-4">
                          <label>Email Address</label><br>
                          <input type="email" class="form-control" name="email" id="email" placeholder="Enter Email Address"/>
                    </div>
                    <div class="form-group  col-md-4">
                          <label>Contact</label>
                          <input type="number" class="form-control" name="contact" id="contact" placeholder="Enter Contact"/>
                    </div>
			     </div>
			  </div>
			  
			  <div class="row">
			     <div class="col-md-12">
			        <div class="form-group col-md-4">
                          <label>Nationality</label>
                          <select class="form-control select2" name="nationality" id="nationality" style="width:100%;">
								<option value="Indian">Indian</option>
								<option value="Foreign_National">Foreign National</option>
						  </select>
                    </div>
                    <div class="form-group col-md-4">
                          <label>Location</label><br>
                          <select class="form-control select2" name="location" id="location" style="width: 100%;">
								<option value="kalyan">kalyan</option>
								<option value="Thane">Thane</option>
						  </select>
                    </div>
                    <div class="form-group  col-md-4">
                          <label>City</label>
                          <select class="form-control select2" name="city" id="city" style="width: 100%;">
								<option value="Mumbai">Mumbai</option>
								<option value="Navi_Mumbai">Navi Mumbai</option>
						  </select>
                    </div>
			     </div>
			  </div>
              <!-- /.box-body -->

			  <h2 style="margin-left:12px"></b>Assign For</b></h2><br>
			     <div class="row">
				  <div class="col-md-12">
			        <div class="form-group col-md-3">
                          <label>Course</label>
                          <select class="form-control select2" name="course" id="course" style="width: 100%;">
								<option value="IT">IT</option>
								<option value="Computer">Computer</option>
								<option value="Mechanical">Mechanical</option>
								<option value="Civil">Civil</option>
								<option value="Automobile">Automobile</option>
								<option value="Elect & Telecom">Elect & Telecom</option>
								<option value="Electrical">Electrical</option>
						  </select>
                    </div>
 					<div class="form-group col-md-3">
                          <label>Year</label>
                          <select class="form-control select2" name="course_year" id="course_year" style="width: 100%;">
								<option value="first Semester">1st Semester</option>
								<option value="second Semester">2nd Semester</option>
								<option value="third semester">3rd Semester</option>
								<option value="fourth semester">4th Semester</option>
								<option value="fifth semester">5th Semester</option>
								<option value="sixth semester">6th Semester</option>
						  </select>
                    </div>
					<div class="form-group col-md-3">
                          <label>Shift</label>
                          <select class="form-control select2" name="shift" id="shift" style="width: 100%;">
								<option value="none">none</option>
								<option value="1st Shift">1st Shift</option>
								<option value="2nd Shift">2nd Shift</option>
						  </select>
                    </div>
					<div class="form-group col-md-3">
                          <label>Subject</label>
                          <select class="form-control select2" name="subject" id="subject" style="width: 100%;">
								<option value="mep">MEP</option>
								<option value="ip">IP</option>
								<option value="cns">CNS</option>
								<option value="ecom">E-Commerce</option>
								<option value="iot">IOT</option>
						  </select>
                    </div>
				  </div>
				 </div>
					
				
              <div class="box-footer">
			    <center>
			    <button type="submit" class="btn btn-primary" name="student_submit" id="student_submit">Submit</button>
                <button type="submit" class="btn btn-warning">Reset</button>
				</center>
              </div>
            </form>
          </div>
          <!-- /.box -->
        </div>
		
		
        
        <!--/.col (right) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  
  <?php include("footer.php")?>