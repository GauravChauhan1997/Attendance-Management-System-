<?php include("header.php")?>

<?php
  
  if(isset($_POST["staffs_update"]))
	 {
		 $id = $_POST["id"];
		 $f_name = $_POST["f_name"];
		 $m_name = $_POST["m_name"];
		 $l_name = $_POST["l_name"];
		 $dob = $_POST["dob"];
		 $age = $_POST["age"];
		 $gender = $_POST["gender"];
		 $cast = $_POST["cast"];
		 $address = $_POST["address"];
		 $email = $_POST["email"];
		 $contact = $_POST["contact"];
		 $nationality = $_POST["nationality"];
		 $location = $_POST["location"];
		 $city = $_POST["city"];
		 $course = $_POST["course"];
		 $course_year = $_POST["course_year"];
		 $shift = $_POST["shift"];
		 $subject = $_POST["subject"];
		 $characters = 'abc123';
		$string = '';
		$string1 = '';
		$string2 = '';
		$string6 = '';
			$profile_image = $_FILES["fruit_img"]["name"];
				
			if($profile_image <> "")
			{

				for($j = 0; $j < count($profile_image); $j++)
				{
					
				for($i = 0; $i < 0; $i++) {
					$string .= $characters[rand(0, strlen($characters) - 1)];
				}	
				$profile_imagePath = "fruit/" . $string . $profile_image[$j];

				move_uploaded_file($_FILES["fruit_img"]["tmp_name"][$j], $profile_imagePath);
				}	
			}
		 
		 
		 $query = "UPDATE `addclient` SET `f_name`='$f_name',`m_name`='$m_name',`l_name`='$l_name',`dob`='$dob',`age`='$age',`gender`='$gender',`cast`='$cast',`address`='$address',`email`='$email',`contact`='$contact',`nationality`='$nationality',`location`='$location',`city`='$city',`course`='$course',`course_year`='$course_year',`shift`='$shift',`subject`='$subject',`image`='$profile_imagePath' WHERE client_id='$id'";
		 
		 $que = mysql_query($query);
		 if($que)
		 {
			 echo'<script>alert("Staff Details Updated")</script>';
		 }
		 else{
			 echo'<script>alert("Something Went Wrong")</script>';
		 }

	 }

     if(isset($_REQUEST["view"]) && $_REQUEST["view"] != "" ) 		
		{
			$details = mysql_query("SELECT * FROM addclient WHERE `client_id` = ".db_prepare_input((int)$_REQUEST["view"]));
			
			while($row_user = mysql_fetch_array($details))
			{
				         $id = $row_user["client_id"];
					     $f_name = $row_user["f_name"];
						 $m_name = $row_user["m_name"];
						 $l_name = $row_user["l_name"];
						 $dob = $row_user["dob"];
						 $age = $row_user["age"];
						 $gender = $row_user["gender"];
						 $cast = $row_user["cast"];
						 $address = $row_user["address"];
						 $email = $row_user["email"];
						 $contact = $row_user["contact"];
						 $nationality = $row_user["nationality"];
						 $location = $row_user["location"];
						 $city = $row_user["city"];
						 $course = $row_user["course"];
						 $course_year = $row_user["course_year"];
						 $shift = $row_user["shift"];
						 $subject = $row_user["subject"];
						 $image = $row_user["image"];
						 $username = $row_user["username"];
	                     $password = $row_user["password"];	
						 
						 if($course == "IT" || $course == "it")
						 {
							 $IT = 'selected';
							 $Computer = '';
							 $Mechanical = '';                       
							 $Civil = '';
							 $Automobile = '';
							 $Elect_Telecom = '';
							 $Electrical = '';
						 }
						 else if($course == "Computer" || $course == "computer")
						 {
							 $IT = '';
							 $Computer = 'selected';
							 $Mechanical = '';                       
							 $Civil = '';
							 $Automobile = '';
							 $Elect_Telecom = '';
							 $Electrical = '';
						 }
						 else if($course == "Mechanical" || $course == "mechanical")
						 {
							 $IT = '';
							 $Computer = '';
							 $Mechanical = 'selected';                       
							 $Civil = '';
							 $Automobile = '';
							 $Elect_Telecom = '';
							 $Electrical = '';
						 }
						 else if($course == "Civil" || $course == "civil")
						 {
							 $IT = '';
							 $Computer = '';
							 $Mechanical = '';                       
							 $Civil = 'selected';
							 $Automobile = '';
							 $Elect_Telecom = '';
							 $Electrical = '';
						 }
						 else if($course == "Automobile" || $course == "automobile")
						 {
							 $IT = '';
							 $Computer = '';
							 $Mechanical = '';                       
							 $Civil = '';
							 $Automobile = 'selected';
							 $Elect_Telecom = '';
							 $Electrical = '';
						 }
						 else if($course == "Elect_Telecom" || $course == "elect_telecom")
						 {
							 $IT = '';
							 $Computer = '';
							 $Mechanical = '';                       
							 $Civil = '';
							 $Automobile = '';
							 $Elect_Telecom = 'selected';
							 $Electrical = '';
						 }
						 else if($course == "Electrical" || $course == "electrical")
						 {
							 $IT = '';
							 $Computer = '';
							 $Mechanical = '';                       
							 $Civil = '';
							 $Automobile = '';
							 $Elect_Telecom = '';
							 $Electrical = 'selected';
						 }
						  if($course_year == "first_Semester" || $course_year == "first_semester")
						 {
							 $first_Semester = 'selected';
							 $second_Semester = '';
							 $third_Semester = '';
							 $fourth_Semester = '';
							 $fifth_Semester = '';
							 $sixth_Semester = '';
						 }
						 else if($course_year == "second_Semester" || $course_year == "second_semester")
						 {
							 $first_Semester = '';
							 $second_Semester = 'selected';
							 $third_Semester = '';
							 $fourth_Semester = '';
							 $fifth_Semester = '';
							 $sixth_Semester = '';
						 } 
						 else if($course_year == "third_Semester" || $course_year == "third_semester")
						 {
							 $first_Semester = '';
							 $second_Semester = '';
							 $third_Semester = 'selected';
							 $fourth_Semester = '';
							 $fifth_Semester = '';
							 $sixth_Semester = '';
						 } 
						 else if($course_year == "fourth_Semester" || $course_year == "fourth_semester")
						 {
							 $first_Semester = '';
							 $second_Semester = '';
							 $third_Semester = '';
							 $fourth_Semester = 'selected';
							 $fifth_Semester = '';
							 $sixth_Semester = '';
						 } 
						 else if($course_year == "fifth_Semester" || $course_year == "fifth_semester")
						 {
							 $first_Semester = '';
							 $second_Semester = '';
							 $third_Semester = '';
							 $fourth_Semester = '';
							 $fifth_Semester = 'selected';
							 $sixth_Semester = '';
						 } 
						 else if($course_year == "sixth_Semester" || $course_year == "sixth_semester")
						 {
							 $first_Semester = '';
							 $second_Semester = '';
							 $third_Semester = '';
							 $fourth_Semester = '';
							 $fifth_Semester = '';
							 $sixth_Semester = 'selected';
						 } 
						
						 
						 
						 if($shift == "none" || $shift == "None")
						 {
							 $None = 'selected';
							 $Shift_1st = '';
							 $Shift_2nd = '';
						 }
						 else if($shift == "1st Shift" || $shift == "1st Shift")
						 {
							 $None = '';
							 $Shift_1st = 'selected';
							 $Shift_2nd = '';
						 } 
						 else if($shift == "2nd Shift" || $shift == "2nd Shift")
						 {
							 $None = '';
							 $Shift_1st = '';
							 $Shift_2nd = 'selected';
						 } 
						 if($subject == "mep" || $subject == "MEP")
						 {
							 $mep = 'selected';
							 $ip = '';
							 $cns = '';
							 $ecom = '';
							 $iot = '';
						 }
						 else if($subject == "ip" || $subject == "IP")
						 {
							 $mep = '';
							 $ip = 'selected';
							 $cns = '';
							 $ecom = '';
							 $iot = '';
						 }
                         else if($subject == "cns" || $subject == "CNS")
						 {
							 $mep = '';
							 $ip = '';
							 $cns = 'selected';
							 $ecom = '';
							 $iot = '';
						 } 
                         else if($subject == "ecom" || $subject == "ECOM")
						 {
							 $mep = '';
							 $ip = '';
							 $cns = '';
							 $ecom = 'selected';
							 $iot = '';
						 } 
                         else if($subject == "iot" || $subject == "IOT")
						 {
							 $mep = '';
							 $ip = '';
							 $cns = '';
							 $ecom = '';
							 $iot = 'selected';
						 } 						 
              }
        }


?>
  
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Edit Staff Record
      </h1>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
            
            <!-- /.box-header -->
            <!-- form start -->
            <form method="post" action="" enctype="multipart/form-data">
              <div class="box-body">
			    <input type="hidden" class="form-control" name="id" id="id" value="<?php echo $id?>"/>
			    <div class="form-group col-md-3">
                      <img src="<?php echo $image?>" id="blah" src="#" name=""  class="img-circle" style="width:100px; height:100px;"/>
					  <input type='file' id="imgInp" style="padding-top:5px" name="fruit_img[]"/>
                </div>
                <div class="form-group col-md-3" style="margin-top:20px">
                  <label>First Name</label>
                  <input type="text" class="form-control" name="f_name" id="f_name" value="<?php echo $f_name?>" placeholder="Enter First Name">
                </div>
                <div class="form-group  col-md-3" style="margin-top:20px">
                  <label>Middle Name</label>
                  <input type="text" class="form-control" name="m_name" id="m_name" value="<?php echo $m_name?>" placeholder="Enter Middle Name">
                </div>
                <div class="form-group  col-md-3" style="margin-top:20px">
                  <label>Last name</label>
                  <input type="text" class="form-control" name="l_name" id="l_name" value="<?php echo $l_name?>" placeholder="Enter Last Name">
                </div>
              </div>
			  
			  <div class="row">
			     <div class="col-md-12">
			        <div class="form-group col-md-2">
                          <label>D.O.B</label>
                          <input type="text" class="form-control" name="dob" id="dob" value="<?php echo $dob?>" placeholder="D.O.B">
                    </div>
					<div class="form-group col-md-2">
                          <label>Age</label>
                          <input type="text" class="form-control" name="age" id="age" value="<?php echo $age?>" placeholder="Age">
                    </div>
                    <div class="form-group col-md-4">
                          <label>Gender</label><br>
                          <select class="form-control select2" name="gender" id="gender" value="<?php echo $gender?>" style="width: 100%;">
								<option value="Male">Male</option>
								<option value="Female">Female</option>
						  </select>
                    </div>
                    <div class="form-group  col-md-4">
                          <label>Cast</label>
                          <select class="form-control select2" name="cast" id="cast" value="<?php echo $cast?>" style="width: 100%;">
								<option value="Hindu">Hindu</option>
								<option value="Marathi">Marathi</option>
								<option value="Gujarati">Gujarati</option>
						  </select>
                    </div>
			     </div>
			  </div>
			  
			  <div class="row">
			     <div class="col-md-12">
			        <div class="form-group col-md-4">
                          <label>Address</label>
                          <input type="text" class="form-control" name="address" id="address" value="<?php echo $address?>" placeholder="Enter Address"/>
                    </div>
                    <div class="form-group col-md-4">
                          <label>Email Address</label><br>
                          <input type="email" class="form-control" name="email" id="email" value="<?php echo $email?>" placeholder="Enter Email Address"/>
                    </div>
                    <div class="form-group  col-md-4">
                          <label>Contact</label>
                          <input type="number" class="form-control" name="contact" id="contact" value="<?php echo $contact?>" placeholder="Enter Contact"/>
                    </div>
			     </div>
			  </div>
			  
			  <div class="row">
			     <div class="col-md-12">
			        <div class="form-group col-md-4">
                          <label>Nationality</label>
                          <select class="form-control select2" name="nationality" id="nationality" value="<?php echo $nationality?>" style="width:100%;">
								<option value="Indian">Indian</option>
								<option value="Foreign_National">Foreign National</option>
						  </select>
                    </div>
                    <div class="form-group col-md-4">
                          <label>Location</label><br>
                          <select class="form-control select2" name="location" id="location" value="<?php echo $location?>" style="width: 100%;">
								<option value="kalyan">kalyan</option>
								<option value="Thane">Thane</option>
						  </select>
                    </div>
                    <div class="form-group  col-md-4">
                          <label>City</label>
                          <select class="form-control select2" name="city" id="city" value="<?php echo $city?>" style="width: 100%;">
								<option value="Mumbai">Mumbai</option>
								<option value="Navi_Mumbai">Navi Mumbai</option>
						  </select>
                    </div>
			     </div>
			  </div>
			  <div class="row">
			      <div class="col-md-12">
					    <div class="form-group" style="margin-top:10px">
					       <div class="col-md-4">
						    <label>Username</label><br>
					 		<b><input type="text" class="form-control sel2" readonly name="username" id="username" value="<?php echo $username?>"/></b>
						   </div>
						   <div class="col-md-4">
						    <label>Password</label><br>
			                <b><input type="text" class="form-control sel2" readonly name="password" id="password" value="<?php echo $password?>"/></b>
						   </div>
					   </div>
				  </div>
			  </div>   
              <!-- /.box-body -->
 <hr>
			  <h2 style="margin-left:12px"></b>Assign For</b></h2><br>
			     <div class="row">
				  <div class="col-md-12">
			        <div class="form-group col-md-3">
                          <label>Course</label>
                          <select class="form-control select2" name="course" id="course" value="<?php echo $course?>" style="width: 100%;">
								<option value="IT" <?php echo $IT?>>IT</option>
								<option value="Computer" <?php echo $Computer?>>Computer</option>
								<option value="Mechanical" <?php echo $Mechanical?>>Mechanical</option>
								<option value="Civil" <?php echo $Civil?>>Civil</option>
								<option value="Automobile" <?php echo $Automobile?>>Automobile</option>
								<option value="Elect and Telecom" <?php echo $Elect_Telecom?>>Elect & Telecom</option>
								<option value="Electrical" <?php echo $Electrical?>>Electrical</option>
						  </select>
                    </div>
 					<div class="form-group col-md-3">
                          <label>Year</label>
                          <select class="form-control select2" name="course_year" id="course_year" value="<?php echo $course_year?>" style="width: 100%;">
								<option value="first_Semester" <?php echo $first_Semester?>>1st Semester</option>
								<option value="second_Semester" <?php echo $second_Semester?>>2nd Semester</option>
								<option value="third_Semester" <?php echo $third_Semester?>>3rd Semester</option>
								<option value="fourth_Semester" <?php echo $fourth_Semester?>>4th Semester</option>
								<option value="fifth_Semester" <?php echo $fifth_Semester?>>5th Semester</option>
								<option value="sixth_Semester" <?php echo $sixth_Semester?>>6th Semester</option>
						  </select>
                    </div>
					<div class="form-group col-md-3">
                          <label>Shift</label>
                          <select class="form-control select2" name="shift" id="shift" value="<?php echo $shift?>" style="width: 100%;">
								<option value="none" <?php echo $None?>>none</option>
								<option value="1st Shift"<?php echo $Shift_1st?>>1st Shift</option>
								<option value="2nd Shift"<?php echo $Shift_2nd?>>2nd Shift</option>
						  </select>
                    </div>
					<div class="form-group col-md-3">
                          <label>Subject</label>
                          <select class="form-control select2" name="subject" id="subject" style="width: 100%;">
								<option value="mep" <?php echo $mep?>>MEP</option>
								<option value="ip" <?php echo $ip?>>IP</option>
								<option value="cns" <?php echo $cns?>>CNS</option>
								<option value="ecom" <?php echo $ecom?>>E-Commerce</option>
								<option value="iot" <?php echo $iot?>>IOT</option>
						  </select>
                    </div>
				  </div>
				 </div>
					
				<br>
              <div class="box-footer">
			    <center>
			    <button type="submit" class="btn btn-warning" id="staffs_update" name="staffs_update">Update</button>
				</center>
              </div>
            </form>
          </div>
          <!-- /.box -->
        </div>
		
		
        
        <!--/.col (right) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  
  <?php include("footer.php")?>