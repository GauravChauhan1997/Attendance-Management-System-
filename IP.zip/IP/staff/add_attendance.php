<?php include("header.php")?>
<?php

if(isset($_POST["attendance_submit"]))
{
	$attendanceCourse = $_POST["attendanceCourse"];
	$attendanceYear = $_POST["attendanceYear"];
	$attendanceShift = $_POST["attendanceShift"];
	$Course = $_POST["Course"];
	$CourseSubject = $_POST["CourseSubject"];
	$CourseAttendance = $_POST["CourseAttendance"];
	$status = '0';
	$createddate = date("M-Y");
	
	$attend = "INSERT INTO `attendance`(`attendanceCourse`,`attendanceYear`,`attendanceShift`,`Course`,`CourseSubject`,`CourseAttendance`,`refstaffid`,
	`status`,`createddate`) 
	VALUES('$attendanceCourse','$attendanceYear','$attendanceShift',
	'$Course','$CourseSubject','$CourseAttendance','$user_check','$status','$createddate')";
	$att = mysql_query($attend);
	if($att)
	{
		echo '<script>alert ("Student Attendance is Done")</script>';
	}else
		{
		echo '<script>alert ("Something Went Wrong")</script>';
	}
}
?>

  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Add Attendance
      </h1>
    </section>
<?php
$que = mysql_query("SELECt * FROM addclient WHERE usertype='staff'");
$row = mysql_fetch_assoc($que);
$cou = $row["course"];
$sub = $row["subject"];
$sem = $row["course_year"];
$shift = $row["shift"];
?>
    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
            
            <!-- /.box-header -->
            <!-- form start -->
            <form method="post" action="" enctype="multipart/form-data">
              
              <!-- /.box-body -->

			  <br>
			     <div class="row">
				  <div class="col-md-12">
				    <div class="form-group col-md-3">
                          <label><?php echo $cou?> Students</label>
						   <select class="form-control select2" name="attendanceCourse" id="attendanceCourse" style="width: 100%;">
<?php

$abc = mysql_query("SELECt * FROM addclient WHERE usertype='user'");
while($rows = mysql_fetch_array($abc))
{
?>								
								<option value="<?php echo $rows["client_id"]?>"><?php echo $rows["f_name"]?> <?php echo $rows["l_name"]?></option>
<?php
}
?>								
						  </select>
					</div>

					<div class="form-group col-md-3">
                          <label>Semester</label>
						   <select class="form-control select2" name="attendanceYear" id="attendanceYear" style="width: 100%;">
								<option value="first_Semester">1st Semester</option>
								<option value="second_Semester">2nd Semester</option>
								<option value="third_semester">3rd Semester</option>
								<option value="fourth_semester">4th Semester</option>
								<option value="fifth_semester">5th Semester</option>
								<option value="sixth_semester">6th Semester</option>
						  </select>
                    </div>
					<div class="form-group col-md-3">
                          <label>Shift</label>
						   <select class="form-control select2" name="attendanceShift" id="attendanceShift" style="width: 100%;">
								<option value="none">none</option>
								<option value="1st Shift">1st Shift</option>
								<option value="2nd Shift">2nd Shift</option>
						  </select>
                    </div>

					<div class="form-group col-md-3">
                          <label>Course</label>
						  <select class="form-control select2" name="Course" id="Course" style="width: 100%;">
								<option value="IT">IT</option>
								<option value="Computer">Computer</option>
								<option value="Mechanical">Mechanical</option>
								<option value="Civil">Civil</option>
								<option value="Automobile">Automobile</option>
								<option value="Elect & Telecom">Elect & Telecom</option>
								<option value="Electrical">Electrical</option>
						  </select>
					</div>
					<div class="form-group col-md-3">
                          <label>Subject</label>
                         <select class="form-control select2" name="CourseSubject" id="CourseSubject" style="width: 100%;">
								<option value="mep">MEP</option>
								<option value="ip">IP</option>
								<option value="cns">CNS</option>
								<option value="ecom">E-Commerce</option>
								<option value="iot">IOT</option>
						  </select>
					</div>
					<div class="form-group col-md-3">
                          <label>Attendance</label>
                          <select class="form-control select2" name="CourseAttendance" id="CourseAttendance" style="width: 100%;">
								<option value="present">Present</option>
								<option value="absent">Absent</option>
						  </select>
                    </div>
				  </div>
				 </div>
					
				
              <div class="box-footer">
			    <center>
			    <button type="submit" class="btn btn-primary" name="attendance_submit" id="attendance_submit">Submit</button>
                <button type="submit" class="btn btn-warning">Reset</button>
				</center>
              </div>
            </form>
          </div>
          <!-- /.box -->
        </div>
		
		
        
        <!--/.col (right) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  
  <?php include("footer.php")?>
 