<?php include("header.php")?>
<?php
    if (isset($_REQUEST["del"]) && $_REQUEST["del"] != "" ) 
		{
			$del = $_REQUEST["del"];
			$query = "DELETE FROM attendance WHERE `attendanceid` = ".$_REQUEST["del"];			
			
			$stmt = mysql_query($query);
			if ($stmt) 
			{
				
				
						echo("<script type='text/javascript'>
						
							alert('Deleted');
					
						</script>");
					
			}
			else 
			{
				
				echo("<script type='text/javascript'>
					
					alert('Not Deleted');
					
						</script>");
				
			}	
		}

?>


<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Attendance Records
        <small>advanced tables</small>
      </h1>
      
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
				  <th><input type="checkbox"/></th>
				  <th>Sr no.</th>
                  <th>Student Name</th>          
                  <th>Course</th>
				  <th>Subject</th>
				  <th>Shift</th>
				  <th>Semester</th>
				  <th>Attendance</th>
                </tr>
                </thead>
                <tbody>
<?php
 $count = 1;
   $query = mysql_query("select * from attendance WHERE refstaffid = '$user_check'");
   
   while($row = mysql_fetch_array($query))
   {
	   $staff = $row["attendanceCourse"];
	   $query2 = mysql_query("SELECT * FROM addclient WHERE client_id = '$staff' ");
	   $abcde = mysql_fetch_assoc($query2);
	   $f_name = $abcde["f_name"];
?>
                <tr>
				  <td><input type="radio" name="chkNumber" class="chkNumber" value="<?php echo $row["attendanceid"]?>"></td>
				  <td><?php echo $count?></td>
                  <td><?php echo $abcde["f_name"]?></td>
				  <td><?php echo $row["Course"]?></td>
				  <td><?php echo $row["CourseSubject"]?></td>
                  <td><?php echo $row["attendanceShift"]?></td>
                  <td><?php echo $row["attendanceYear"]?></td>
				  <td><?php echo $row["CourseAttendance"]?></td>
                </tr>
<?php
$count++;
   }
?>
				
              </tbody>
              </table><br>
              <button type="submit" class="btn btn-danger" id="delete" name="delete">Delete</button>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
	
    <!-- /.content -->
  </div>
<?php include("footer.php")?>

<script>
 $(document).on("click","#delete",function(e){
		
			if ($('.chkNumber:checked').length) {
				  var chkId = '';
				  $('.chkNumber:checked').each(function () {
					chkId += $(this).val() + ",";
				  });
				  chkId = chkId.slice(0, -1);
				 //alert(chkId);
				 location.href = "index.php?del=" + chkId ;
				}
				else {
				  alert('Nothing Selected');
				}
			
		});
</script>
