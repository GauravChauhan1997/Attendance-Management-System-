<?php include("header.php")?>
<?php

   $totalno = mysql_query("select count(*) as total from attendance WHERE attendanceCourse = '$user_check' && CourseAttendance='present'");
	$row_user = mysql_fetch_assoc($totalno);
	$total_students = $row_user["total"];
	
	$asdf = ($total_students/60)*100;
?>

  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Check Attendance
      </h1>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
            
            <!-- /.box-header -->
            <!-- form start -->
            <form method="get" action="" enctype="http://localhost/IP2/student/Check_attendance.php">
        	  
			 <br>
			 
			  <div class="row">
			        <div class="col-md-12">
						<div class="form-group col-md-4">
						  </div>
						<div class="form-group  col-md-4">
						  <input type="text" class="form-control" name="presentdate" id="presentdate" placeholder="Enter Date">
						</div>
						<div class="form-group  col-md-4">
						  </div>
					 </div>
			  </div>
			  
				
              <div class="box-footer">
			    <center>
			    <button type="submit" class="btn btn-warning">Show Result</button>
				</center>
              </div>
			  <div class="row">
			          <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
				<p style="font-size:20px">Attendance Percentage : <?php echo $asdf?>%</p>
				
                <tr>
				  <th>Staff Name</th>
                  <th>Subject</th>
                  <th>Semester</th>
                  <th>Attendance</th>			  
                </tr>
                </thead>
                <tbody>
<?php
if(isset($_REQUEST["presentdate"]))
{
	$presentdate = $_REQUEST["presentdate"];
   $query = mysql_query("select * from attendance WHERE attendanceCourse = '$user_check' and createddate='$presentdate'");
   $total_records = mysql_num_rows($query);
   if($total_records > 0)
	{
   while($row = mysql_fetch_array($query))
   {
	   $staff = $row["refstaffid"];
	   $query2 = mysql_query("SELECT * FROM addclient WHERE client_id = '$staff' ");
	   $abcde = mysql_fetch_assoc($query2);
	   $f_name = $abcde["f_name"];
	    $l_name = $abcde["l_name"];
	   $subject = $abcde["subject"];
	   $course_year = $abcde["course_year"];
	   $CourseAttendance = $row["CourseAttendance"];
	   
?>
                
				
                <tr>
                  <td><?php echo $f_name?> <?php echo $l_name?></td>
                  <td><?php echo $subject?></td>
                  <td><?php echo $course_year?></td>
                  <td><?php echo $CourseAttendance?></td>				  
                </tr>
				
<?php
   } 
}
else
{
		echo 'No Record Found';
}
	
 }
?>
				
              </tbody>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
			  
			  </div>
            </form>
          </div>
          <!-- /.box -->
        </div>
		
		
        
        <!--/.col (right) -->
      </div>
      <!-- /.row -->
    </section>
	
    <!-- /.content -->
  </div>
  
  <?php include("footer.php")?>